/* BillVault mobile-first dApp. Testnet only. */
(function () {
  const CHAIN_ID = 31611;
  const CHAIN_HEX = "0x" + CHAIN_ID.toString(16);
  const RPC = "https://rpc.test.mezo.org";
  const EXPLORER = "https://explorer.test.mezo.org";
  const MUSD = "0x118917a40FAF1CD7a13dB0Ef56C86De7973Ac503";
  const SAVINGS = "0x6f461c68B2c5492C0F5CCEc5a264d692aA7A8e16";

  let CONTRACT = null;
  let provider = null;
  let browserProvider = null;
  let signer = null;
  let account = null;
  let readProvider = null;

  const $ = (id) => document.getElementById(id);
  const status = (el, msg, kind) => {
    el.textContent = msg || "";
    el.className = "status" + (kind ? " " + kind : "");
  };
  const short = (a) => (a ? a.slice(0, 6) + "…" + a.slice(-4) : "");
  const fmt = (v, d = 4) => {
    try { return Number(ethers.formatUnits(v, 18)).toLocaleString(undefined, { maximumFractionDigits: d }); }
    catch { return "0"; }
  };
  const txLink = (h) => `${EXPLORER}/tx/${h}`;
  const addrLink = (a) => `${EXPLORER}/address/${a}`;
  const shortErr = (e) => {
    const m = e?.shortMessage || e?.reason || e?.message || String(e);
    return m.length > 220 ? m.slice(0, 220) + "…" : m;
  };

  function getInjected() {
    if (window.okxwallet) return window.okxwallet;
    const eth = window.ethereum;
    if (!eth) return null;
    if (eth.isOkxWallet || eth.isOKExWallet || eth.isOKXWallet) return eth;
    if (Array.isArray(eth.providers)) {
      const okx = eth.providers.find((p) => p.isOkxWallet || p.isOKExWallet || p.isOKXWallet);
      if (okx) return okx;
    }
    return eth;
  }

  async function loadContract() {
    const res = await fetch("contract.json");
    CONTRACT = await res.json();
  }

  function getReadProvider() {
    if (!readProvider) readProvider = new ethers.JsonRpcProvider(RPC, CHAIN_ID, { staticNetwork: true });
    return readProvider;
  }

  async function connect() {
    const inj = getInjected();
    if (!inj) {
      status($("walletStatus"), "No wallet detected. Open this page inside OKX Wallet’s Web3 browser, or use a compatible EVM wallet.", "err");
      return;
    }
    try {
      provider = inj;
      browserProvider = new ethers.BrowserProvider(inj);
      const accounts = await inj.request({ method: "eth_requestAccounts" });
      account = accounts[0];
      signer = await browserProvider.getSigner();
      const net = await browserProvider.getNetwork();
      $("connectBtn").textContent = short(account);
      $("switchBtn").classList.toggle("hidden", Number(net.chainId) === CHAIN_ID);
      status($("walletStatus"), `Connected: ${account} · chain ${net.chainId}`, Number(net.chainId) === CHAIN_ID ? "ok" : "err");
      if (Number(net.chainId) !== CHAIN_ID) await switchNetwork();
      renderBills();
    } catch (e) {
      status($("walletStatus"), "Connect failed: " + shortErr(e), "err");
    }
  }

  async function switchNetwork() {
    if (!provider) return connect();
    try {
      await provider.request({ method: "wallet_switchEthereumChain", params: [{ chainId: CHAIN_HEX }] });
    } catch (e) {
      if (e?.code === 4902 || /Unrecognized chain|not added|unknown chain/i.test(e?.message || "")) {
        try {
          await provider.request({
            method: "wallet_addEthereumChain",
            params: [{
              chainId: CHAIN_HEX,
              chainName: "Mezo Testnet",
              nativeCurrency: { name: "Bitcoin", symbol: "BTC", decimals: 18 },
              rpcUrls: [RPC],
              blockExplorerUrls: [EXPLORER],
            }],
          });
        } catch (e2) {
          status($("walletStatus"), "Add network failed: " + shortErr(e2), "err");
          return;
        }
      } else {
        status($("walletStatus"), "Switch network failed: " + shortErr(e), "err");
        return;
      }
    }
    browserProvider = new ethers.BrowserProvider(provider);
    signer = await browserProvider.getSigner();
    $("switchBtn").classList.add("hidden");
    status($("walletStatus"), `Connected: ${account} · Mezo Testnet`, "ok");
  }

  async function ensureChain() {
    if (!browserProvider) throw new Error("Connect wallet first");
    const net = await browserProvider.getNetwork();
    if (Number(net.chainId) !== CHAIN_ID) {
      await switchNetwork();
      const n2 = await browserProvider.getNetwork();
      if (Number(n2.chainId) !== CHAIN_ID) throw new Error("Wrong network. Please switch to Mezo Testnet.");
    }
  }

  function billContract(address, runner) {
    return new ethers.Contract(address, CONTRACT.abi, runner || getReadProvider());
  }

  function musdContract(runner) {
    return new ethers.Contract(MUSD, [
      "function balanceOf(address) view returns (uint256)",
      "function allowance(address,address) view returns (uint256)",
      "function approve(address,uint256) returns (bool)",
      "function decimals() view returns (uint8)",
    ], runner || getReadProvider());
  }

  function saveBill(address) {
    const list = JSON.parse(localStorage.getItem("billvault.bills") || "[]");
    if (!list.includes(address)) {
      list.unshift(address);
      localStorage.setItem("billvault.bills", JSON.stringify(list));
    }
  }

  function addTx(label, hash, address) {
    const list = JSON.parse(localStorage.getItem("billvault.txs") || "[]");
    list.unshift({ label, hash, address, at: Date.now() });
    localStorage.setItem("billvault.txs", JSON.stringify(list.slice(0, 50)));
    renderTx();
  }

  function renderTx() {
    const list = JSON.parse(localStorage.getItem("billvault.txs") || "[]");
    const ul = $("txList");
    ul.innerHTML = "";
    if (!list.length) {
      ul.innerHTML = '<li class="muted">No local transactions yet.</li>';
      return;
    }
    for (const t of list) {
      const li = document.createElement("li");
      li.innerHTML = `${t.label}: <a href="${txLink(t.hash)}" target="_blank" rel="noreferrer">${short(t.hash)}</a> · <a href="${addrLink(t.address)}" target="_blank" rel="noreferrer">${short(t.address)}</a>`;
      ul.appendChild(li);
    }
  }

  function statusName(s) {
    return ["Open", "Paid", "Cancelled"][Number(s)] || "Unknown";
  }

  async function billCard(address, actions) {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `<h4>Loading ${short(address)}…</h4>`;
    try {
      const c = billContract(address);
      const s = await c.summary();
      const [owner, payee, target, dueAt, principal, st, pendingYield, title] = s;
      const stName = statusName(st);
      const badgeClass = stName.toLowerCase();
      const due = new Date(Number(dueAt) * 1000).toLocaleString();
      card.innerHTML = `
        <div class="row" style="justify-content:space-between">
          <h4 style="margin:0">${escapeHtml(title || "Bill")}</h4>
          <span class="badge ${badgeClass}">${stName}</span>
        </div>
        <div class="muted" style="margin:6px 0">${short(address)} · <a href="${addrLink(address)}" target="_blank" rel="noreferrer">explorer</a></div>
        <div class="kv">
          <div><span>Target</span>${fmt(target)} MUSD</div>
          <div><span>Funded</span>${fmt(principal)} MUSD</div>
          <div><span>Pending yield</span>${fmt(pendingYield, 6)} MUSD</div>
          <div><span>Due</span>${due}</div>
          <div><span>Payee</span>${short(payee)}</div>
          <div><span>Owner</span>${short(owner)}</div>
        </div>
      `;
      if (actions && Number(st) === 0) {
        const row = document.createElement("div");
        row.className = "row";
        row.innerHTML = `
          <input class="fundAmount" type="number" step="0.000000000000000001" min="0" placeholder="MUSD to fund" style="flex:1;min-width:140px;margin:0" />
          <button class="primary small fundBtn">Fund</button>
          <button class="ghost small payBtn">Pay</button>
          <button class="ghost small cancelBtn">Cancel</button>
        `;
        card.appendChild(row);
        const msg = document.createElement("div");
        msg.className = "status";
        card.appendChild(msg);

        row.querySelector(".fundBtn").onclick = async () => {
          try {
            await ensureChain();
            const amtStr = row.querySelector(".fundAmount").value;
            if (!amtStr || Number(amtStr) <= 0) throw new Error("Enter amount");
            const amt = ethers.parseUnits(amtStr, 18);
            const musd = musdContract(signer);
            const bal = await musd.balanceOf(account);
            if (bal < amt) throw new Error("Insufficient MUSD balance");
            status(msg, "Approving MUSD…");
            const appTx = await musd.approve(address, amt);
            await appTx.wait();
            addTx("Approve", appTx.hash, address);
            status(msg, "Funding bill…");
            const tx = await billContract(address, signer).fund(amt);
            await tx.wait();
            addTx("Fund", tx.hash, address);
            status(msg, "Funded: " + tx.hash, "ok");
            refreshAll();
          } catch (e) { status(msg, shortErr(e), "err"); }
        };
        row.querySelector(".payBtn").onclick = async () => {
          try {
            await ensureChain();
            status(msg, "Paying bill…");
            const tx = await billContract(address, signer).pay();
            await tx.wait();
            addTx("Pay", tx.hash, address);
            status(msg, "Paid: " + tx.hash, "ok");
            refreshAll();
          } catch (e) { status(msg, shortErr(e), "err"); }
        };
        row.querySelector(".cancelBtn").onclick = async () => {
          try {
            await ensureChain();
            status(msg, "Cancelling…");
            const tx = await billContract(address, signer).cancel();
            await tx.wait();
            addTx("Cancel", tx.hash, address);
            status(msg, "Cancelled: " + tx.hash, "ok");
            refreshAll();
          } catch (e) { status(msg, shortErr(e), "err"); }
        };
      }
    } catch (e) {
      card.innerHTML = `<h4>${short(address)}</h4><div class="status err">Failed to load: ${shortErr(e)}</div>`;
    }
    return card;
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  async function renderBills() {
    const list = JSON.parse(localStorage.getItem("billvault.bills") || "[]");
    const wrap = $("billsList");
    wrap.innerHTML = "";
    if (!list.length) {
      wrap.innerHTML = '<p class="muted">No bills yet. Create one, or add an existing bill vault address.</p>';
      return;
    }
    for (const a of list) {
      wrap.appendChild(await billCard(a, true));
    }
  }

  async function refreshAll() {
    await renderBills();
    renderTx();
  }

  async function createBill(e) {
    e.preventDefault();
    const el = $("createStatus");
    try {
      await ensureChain();
      if (!CONTRACT) await loadContract();
      const f = new FormData(e.target);
      const title = String(f.get("title") || "").trim();
      const payee = String(f.get("payee") || "").trim();
      const amount = String(f.get("amount") || "").trim();
      const due = String(f.get("due") || "");
      if (!ethers.isAddress(payee)) throw new Error("Invalid payee address");
      if (!title) throw new Error("Title required");
      const target = ethers.parseUnits(amount, 18);
      if (target <= 0n) throw new Error("Amount must be > 0");
      const dueAt = Math.floor(new Date(due).getTime() / 1000);
      if (!Number.isFinite(dueAt) || dueAt <= Math.floor(Date.now() / 1000)) throw new Error("Due date must be in the future");

      status(el, "Deploying bill vault… confirm in OKX Wallet.");
      const factory = new ethers.ContractFactory(CONTRACT.abi, CONTRACT.bytecode, signer);
      const contract = await factory.deploy(MUSD, SAVINGS, payee, target, dueAt, title);
      status(el, "Waiting for deployment confirmation…");
      await contract.deploymentTransaction().wait();
      const address = await contract.getAddress();
      saveBill(address);
      addTx("Deploy", contract.deploymentTransaction().hash, address);
      status(el, `Deployed: ${address}`, "ok");
      e.target.reset();
      showTab("bills");
      refreshAll();
    } catch (e) {
      status(el, shortErr(e), "err");
    }
  }

  function showTab(name) {
    document.querySelectorAll(".tab").forEach((b) => b.classList.toggle("active", b.dataset.tab === name));
    document.querySelectorAll(".panel").forEach((p) => p.classList.add("hidden"));
    $("tab-" + name).classList.remove("hidden");
    if (name === "bills") renderBills();
    if (name === "evidence") renderTx();
  }

  async function init() {
    await loadContract();
    $("connectBtn").onclick = connect;
    $("switchBtn").onclick = switchNetwork;
    $("createForm").onsubmit = createBill;
    document.querySelectorAll(".tab").forEach((b) => (b.onclick = () => showTab(b.dataset.tab)));
    $("addBillBtn").onclick = () => {
      const a = $("addBillAddress").value.trim();
      if (!ethers.isAddress(a)) return alert("Invalid address");
      saveBill(a);
      $("addBillAddress").value = "";
      renderBills();
    };
    $("verifyBtn").onclick = async () => {
      const a = $("verifyAddress").value.trim();
      if (!ethers.isAddress(a)) return alert("Invalid address");
      const wrap = $("verifyResult");
      wrap.innerHTML = "";
      wrap.appendChild(await billCard(a, false));
    };
    // default due date: tomorrow
    const d = new Date(Date.now() + 24 * 3600 * 1000);
    const pad = (n) => String(n).padStart(2, "0");
    document.querySelector('input[name="due"]').value = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    renderTx();
    // auto-connect if already authorized
    const inj = getInjected();
    if (inj && inj.request) {
      try {
        const accs = await inj.request({ method: "eth_accounts" });
        if (accs && accs.length) connect();
      } catch {}
    }
  }

  init().catch((e) => status($("walletStatus"), shortErr(e), "err"));
})();
