const { expect } = require("chai");
const { ethers } = require("hardhat");
const { loadFixture, time } = require("@nomicfoundation/hardhat-toolbox/network-helpers");

describe("BillVault", function () {
  const TARGET = ethers.parseEther("100");
  const FUND = ethers.parseEther("120");

  async function deployFixture() {
    const [owner, payee, funder, stranger] = await ethers.getSigners();

    const MockMUSD = await ethers.getContractFactory("MockMUSD");
    const musd = await MockMUSD.deploy();

    const MockSavingsRate = await ethers.getContractFactory("MockSavingsRate");
    const savings = await MockSavingsRate.deploy(await musd.getAddress());

    await musd.mint(owner.address, ethers.parseEther("10000"));
    await musd.mint(funder.address, ethers.parseEther("10000"));
    await musd.mint(stranger.address, ethers.parseEther("10000"));

    const dueAt = (await time.latest()) + 7 * 24 * 60 * 60;
    const BillVault = await ethers.getContractFactory("BillVault");
    const vault = await BillVault.deploy(
      await musd.getAddress(),
      await savings.getAddress(),
      payee.address,
      TARGET,
      dueAt,
      "Supplier invoice"
    );

    return { musd, savings, vault, owner, payee, funder, stranger, dueAt };
  }

  it("creates a bill with correct metadata", async function () {
    const { vault, owner, payee, dueAt } = await loadFixture(deployFixture);
    expect(await vault.owner()).to.equal(owner.address);
    expect(await vault.payee()).to.equal(payee.address);
    expect(await vault.targetAmount()).to.equal(TARGET);
    expect(await vault.dueAt()).to.equal(dueAt);
    expect(await vault.status()).to.equal(0);
    expect(await vault.title()).to.equal("Supplier invoice");
  });

  it("funds bill and deposits into savings vault", async function () {
    const { musd, savings, vault, owner } = await loadFixture(deployFixture);
    await musd.connect(owner).approve(await vault.getAddress(), FUND);
    await expect(vault.connect(owner).fund(FUND))
      .to.emit(vault, "Funded")
      .withArgs(owner.address, FUND, FUND);
    expect(await vault.principal()).to.equal(FUND);
    expect(await savings.balanceOf(await vault.getAddress())).to.equal(FUND);
    expect(await musd.balanceOf(await vault.getAddress())).to.equal(0);
  });

  it("rejects zero funding", async function () {
    const { vault, owner } = await loadFixture(deployFixture);
    await expect(vault.connect(owner).fund(0)).to.be.revertedWithCustomError(vault, "ZeroAmount");
  });

  it("rejects funding without approval", async function () {
    const { vault, owner } = await loadFixture(deployFixture);
    await expect(vault.connect(owner).fund(FUND)).to.be.reverted;
  });

  it("allows owner to pay early and returns surplus", async function () {
    const { musd, vault, owner, payee } = await loadFixture(deployFixture);
    await musd.connect(owner).approve(await vault.getAddress(), FUND);
    await vault.connect(owner).fund(FUND);

    const payeeBefore = await musd.balanceOf(payee.address);
    const ownerBefore = await musd.balanceOf(owner.address);

    await expect(vault.connect(owner).pay())
      .to.emit(vault, "Paid")
      .withArgs(owner.address, TARGET, FUND - TARGET);

    expect(await musd.balanceOf(payee.address)).to.equal(payeeBefore + TARGET);
    expect(await musd.balanceOf(owner.address)).to.equal(ownerBefore + (FUND - TARGET));
    expect(await vault.status()).to.equal(1);
    expect(await vault.principal()).to.equal(0);
  });

  it("blocks stranger from paying before due date", async function () {
    const { musd, vault, owner, stranger } = await loadFixture(deployFixture);
    await musd.connect(owner).approve(await vault.getAddress(), FUND);
    await vault.connect(owner).fund(FUND);
    await expect(vault.connect(stranger).pay()).to.be.revertedWithCustomError(vault, "NotOwner");
  });

  it("allows anyone to pay after due date", async function () {
    const { musd, vault, owner, payee, stranger, dueAt } = await loadFixture(deployFixture);
    await musd.connect(owner).approve(await vault.getAddress(), TARGET);
    await vault.connect(owner).fund(TARGET);
    await time.increaseTo(dueAt + 1);
    await expect(vault.connect(stranger).pay()).to.emit(vault, "Paid");
    expect(await musd.balanceOf(payee.address)).to.equal(TARGET);
  });

  it("blocks payment when underfunded", async function () {
    const { musd, vault, owner } = await loadFixture(deployFixture);
    await musd.connect(owner).approve(await vault.getAddress(), ethers.parseEther("50"));
    await vault.connect(owner).fund(ethers.parseEther("50"));
    await expect(vault.connect(owner).pay()).to.be.revertedWithCustomError(vault, "Underfunded");
  });

  it("blocks double payment", async function () {
    const { musd, vault, owner } = await loadFixture(deployFixture);
    await musd.connect(owner).approve(await vault.getAddress(), TARGET);
    await vault.connect(owner).fund(TARGET);
    await vault.connect(owner).pay();
    await expect(vault.connect(owner).pay()).to.be.revertedWithCustomError(vault, "InvalidStatus");
  });

  it("allows owner to cancel and return funds", async function () {
    const { musd, vault, owner } = await loadFixture(deployFixture);
    await musd.connect(owner).approve(await vault.getAddress(), FUND);
    await vault.connect(owner).fund(FUND);
    const before = await musd.balanceOf(owner.address);
    await expect(vault.connect(owner).cancel()).to.emit(vault, "Cancelled");
    expect(await musd.balanceOf(owner.address)).to.equal(before + FUND);
    expect(await vault.status()).to.equal(2);
  });

  it("blocks stranger from cancelling", async function () {
    const { vault, stranger } = await loadFixture(deployFixture);
    await expect(vault.connect(stranger).cancel()).to.be.revertedWithCustomError(vault, "NotOwner");
  });

  it("blocks cancel after payment", async function () {
    const { musd, vault, owner } = await loadFixture(deployFixture);
    await musd.connect(owner).approve(await vault.getAddress(), TARGET);
    await vault.connect(owner).fund(TARGET);
    await vault.connect(owner).pay();
    await expect(vault.connect(owner).cancel()).to.be.revertedWithCustomError(vault, "InvalidStatus");
  });

  it("returns yield to owner on payment", async function () {
    const { musd, savings, vault, owner, payee } = await loadFixture(deployFixture);
    await musd.connect(owner).approve(await vault.getAddress(), TARGET);
    await vault.connect(owner).fund(TARGET);

    // Simulate protocol yield: owner funds mock vault with extra MUSD.
    const yieldAmount = ethers.parseEther("5");
    await musd.connect(owner).approve(await savings.getAddress(), yieldAmount);
    await savings.connect(owner).simulateYield(yieldAmount);
    await savings.checkpoint(await vault.getAddress());

    expect(await vault.pendingYield()).to.equal(yieldAmount);

    const ownerBefore = await musd.balanceOf(owner.address);
    await vault.connect(owner).pay();
    expect(await musd.balanceOf(payee.address)).to.equal(TARGET);
    expect(await musd.balanceOf(owner.address)).to.equal(ownerBefore + yieldAmount);
  });

  it("rejects invalid constructor args", async function () {
    const { musd, savings, payee, owner } = await loadFixture(deployFixture);
    const BillVault = await ethers.getContractFactory("BillVault");
    const musdAddr = await musd.getAddress();
    const savingsAddr = await savings.getAddress();
    const future = (await time.latest()) + 1000;

    await expect(
      BillVault.deploy(ethers.ZeroAddress, savingsAddr, payee.address, TARGET, future, "x")
    ).to.be.revertedWithCustomError(BillVault, "ZeroAddress");

    await expect(
      BillVault.deploy(musdAddr, savingsAddr, ethers.ZeroAddress, TARGET, future, "x")
    ).to.be.revertedWithCustomError(BillVault, "ZeroAddress");

    await expect(
      BillVault.deploy(musdAddr, savingsAddr, payee.address, 0, future, "x")
    ).to.be.revertedWithCustomError(BillVault, "ZeroAmount");

    await expect(
      BillVault.deploy(musdAddr, savingsAddr, payee.address, TARGET, 1, "x")
    ).to.be.revertedWithCustomError(BillVault, "InvalidDueDate");

    await expect(
      BillVault.deploy(musdAddr, savingsAddr, payee.address, TARGET, future, "a".repeat(65))
    ).to.be.revertedWithCustomError(BillVault, "TitleTooLong");

    // Wrong MUSD address for vault.
    const MockMUSD = await ethers.getContractFactory("MockMUSD");
    const otherMusd = await MockMUSD.deploy();
    await expect(
      BillVault.deploy(await otherMusd.getAddress(), savingsAddr, payee.address, TARGET, future, "x")
    ).to.be.revertedWithCustomError(BillVault, "VaultAssetMismatch");
  });

  it("rejects native BTC transfers", async function () {
    const { vault, owner } = await loadFixture(deployFixture);
    await expect(
      owner.sendTransaction({ to: await vault.getAddress(), value: 1 })
    ).to.be.revertedWith("BillVault: no native BTC");
  });

  it("allows third party to fund bill", async function () {
    const { musd, vault, funder } = await loadFixture(deployFixture);
    await musd.connect(funder).approve(await vault.getAddress(), TARGET);
    await expect(vault.connect(funder).fund(TARGET)).to.emit(vault, "Funded");
    expect(await vault.principal()).to.equal(TARGET);
  });
});
