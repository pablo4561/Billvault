# Security notes

BillVault is a hackathon prototype on Mezo testnet. It is not audited and must not be used with real funds.

## Design choices

- One contract per bill isolates funds and yield accounting.
- No admin, no owner privileges over funds after deployment except bill owner actions.
- No upgradeability.
- Reentrancy guard on fund/pay/cancel.
- SafeERC20 for token transfers.
- Exact approval per funding action from the frontend.
- Balance-delta check after savings withdrawal.
- Constructor verifies `savings.musdToken() == musd`.
- Contract rejects native BTC transfers.

## Known risks

- Canonical vault risk: BillVault depends on Mezo’s sMUSD vault behaving as documented.
- Yield risk: yield is variable and may be zero.
- Smart contract risk: unaudited code may contain bugs.
- Frontend risk: users must verify contract addresses and transaction details in their wallet.
- One-contract-per-bill model increases deployment gas and management overhead.
- Permissionless payment after due date means anyone can trigger settlement, but funds only go to the immutable payee and owner.

## Do not claim

- Audited.
- Mainnet ready.
- Guaranteed yield.
- Risk-free.
- Production revenue.
