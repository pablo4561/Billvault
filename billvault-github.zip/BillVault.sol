// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/// @notice Minimal interface for Mezo's native MUSD Savings Rate (sMUSD).
/// @dev This is NOT ERC-4626. sMUSD is minted/burned 1:1 against MUSD principal.
///      Yield is tracked by a global index and claimed as MUSD.
interface IMUSDSavingsRate {
    function musdToken() external view returns (address);
    function deposit(uint256 amount) external;
    function withdraw(uint256 amount) external;
    function claimYield() external returns (uint256);
    function claimableYield(address account) external view returns (uint256);
    function yieldIndex() external view returns (uint256);
    function supplyYieldIndex(address account) external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
}

/// @title BillVault
/// @notice One bill = one isolated yield-bearing MUSD vault.
///         Fund a future bill with MUSD, earn native Mezo savings yield while waiting,
///         then pay the biller directly on-chain. Surplus + yield return to the owner.
/// @dev Testnet-first MVP. No admin, no upgrades, no custody of user funds outside this bill.
contract BillVault is ReentrancyGuard {
    using SafeERC20 for IERC20;

    enum Status { Open, Paid, Cancelled }

    IERC20 public immutable musd;
    IMUSDSavingsRate public immutable savings;

    address public immutable owner;
    address public immutable payee;
    uint256 public immutable targetAmount;
    uint64 public immutable dueAt;
    string public title;

    uint256 public principal;
    Status public status;

    event Funded(address indexed funder, uint256 amount, uint256 newPrincipal);
    event Paid(address indexed payer, uint256 paidToPayee, uint256 returnedToOwner);
    event Cancelled(address indexed owner, uint256 returnedToOwner);

    error NotOwner();
    error InvalidStatus();
    error ZeroAmount();
    error ZeroAddress();
    error Underfunded();
    error ShortWithdrawal();
    error VaultAssetMismatch();
    error InvalidDueDate();
    error TitleTooLong();

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner();
        _;
    }

    constructor(
        address musd_,
        address savings_,
        address payee_,
        uint256 targetAmount_,
        uint64 dueAt_,
        string memory title_
    ) {
        if (musd_ == address(0) || savings_ == address(0) || payee_ == address(0)) revert ZeroAddress();
        if (targetAmount_ == 0) revert ZeroAmount();
        if (dueAt_ <= block.timestamp) revert InvalidDueDate();
        if (bytes(title_).length > 64) revert TitleTooLong();

        if (IMUSDSavingsRate(savings_).musdToken() != musd_) revert VaultAssetMismatch();

        musd = IERC20(musd_);
        savings = IMUSDSavingsRate(savings_);
        owner = msg.sender;
        payee = payee_;
        targetAmount = targetAmount_;
        dueAt = dueAt_;
        title = title_;
        status = Status.Open;
    }

    /// @notice Fund the bill with MUSD. Funds are deposited into Mezo's native savings vault.
    function fund(uint256 amount) external nonReentrant {
        if (status != Status.Open) revert InvalidStatus();
        if (amount == 0) revert ZeroAmount();

        musd.safeTransferFrom(msg.sender, address(this), amount);
        musd.forceApprove(address(savings), amount);

        uint256 sharesBefore = savings.balanceOf(address(this));
        savings.deposit(amount);
        uint256 sharesMinted = savings.balanceOf(address(this)) - sharesBefore;
        if (sharesMinted < amount) revert ShortWithdrawal();

        principal += amount;
        emit Funded(msg.sender, amount, principal);
    }

    /// @notice Pay the bill. Owner can pay early; anyone can pay after due date.
    ///         Withdraws all principal, pays target to payee, returns surplus + yield to owner.
    function pay() external nonReentrant {
        if (status != Status.Open) revert InvalidStatus();
        if (msg.sender != owner && block.timestamp < dueAt) revert NotOwner();
        if (principal < targetAmount) revert Underfunded();

        uint256 principalCache = principal;
        principal = 0;
        status = Status.Paid;

        uint256 musdBefore = musd.balanceOf(address(this));
        savings.withdraw(principalCache);
        uint256 received = musd.balanceOf(address(this)) - musdBefore;
        if (received < principalCache) revert ShortWithdrawal();

        musd.safeTransfer(payee, targetAmount);
        uint256 returned = received - targetAmount;
        if (returned > 0) {
            musd.safeTransfer(owner, returned);
        }

        emit Paid(msg.sender, targetAmount, returned);
    }

    /// @notice Cancel before payment and return principal + yield to owner.
    function cancel() external onlyOwner nonReentrant {
        if (status != Status.Open) revert InvalidStatus();

        uint256 principalCache = principal;
        principal = 0;
        status = Status.Cancelled;

        uint256 returned = 0;
        if (principalCache > 0) {
            uint256 musdBefore = musd.balanceOf(address(this));
            savings.withdraw(principalCache);
            returned = musd.balanceOf(address(this)) - musdBefore;
            if (returned < principalCache) revert ShortWithdrawal();
            musd.safeTransfer(owner, returned);
        }

        emit Cancelled(owner, returned);
    }

    /// @notice Estimated claimable yield for this vault. May be stale until checkpointed.
    function pendingYield() public view returns (uint256) {
        uint256 shares = savings.balanceOf(address(this));
        uint256 stored = savings.claimableYield(address(this));
        uint256 uncheckpointed = 0;
        if (shares > 0) {
            uint256 idx = savings.yieldIndex();
            uint256 userIdx = savings.supplyYieldIndex(address(this));
            if (idx > userIdx) {
                uncheckpointed = (shares * (idx - userIdx)) / 1e18;
            }
        }
        return stored + uncheckpointed;
    }

    /// @notice Estimated total reserve: principal + pending yield.
    function totalReserve() external view returns (uint256) {
        return principal + pendingYield();
    }

    function isOpen() external view returns (bool) {
        return status == Status.Open;
    }

    function isFunded() external view returns (bool) {
        return principal >= targetAmount;
    }

    function summary()
        external
        view
        returns (
            address owner_,
            address payee_,
            uint256 targetAmount_,
            uint64 dueAt_,
            uint256 principal_,
            uint8 status_,
            uint256 pendingYield_,
            string memory title_
        )
    {
        return (owner, payee, targetAmount, dueAt, principal, uint8(status), pendingYield(), title);
    }

    receive() external payable {
        revert("BillVault: no native BTC");
    }
}
