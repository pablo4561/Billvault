# BillVault

**Yield-bearing MUSD bill payments on Mezo.**

BillVault lets you earmark MUSD for a future bill, earn native Mezo savings yield while you wait, and pay the biller directly on-chain.

> Mezo Buildathon prototype. **Testnet only. Not audited. No real funds.**

## What it does

1. Create a bill: title, payee, MUSD amount, due date.
2. Deploy a small isolated `BillVault` contract for that bill.
3. Fund it with MUSD.
4. The contract deposits MUSD into Mezo’s canonical **MUSD Savings Rate / sMUSD** vault.
5. When ready, pay the bill:
   - owner can pay early;
   - anyone can trigger payment after the due date;
   - payee receives the target MUSD amount;
   - surplus + claimed yield return to the owner.
6. Owner can cancel before payment and withdraw funds.

## Why this is Mezo-native

This is not just an ERC-20 payment link. BillVault composes directly with Mezo’s native savings vault:

- MUSD testnet: `0x118917a40FAF1CD7a13dB0Ef56C86De7973Ac503`
- sMUSD / MUSD Savings Rate testnet: `0x6f461c68B2c5492C0F5CCEc5a264d692aA7A8e16`
- Chain ID: `31611`

The contract calls:

- `savings.deposit(amount)`
- `savings.withdraw(amount)`
- `savings.balanceOf(address)`
- `savings.claimableYield(address)`
- `savings.yieldIndex()`
- `savings.supplyYieldIndex(address)`

## Architecture

- `contracts/BillVault.sol`: one bill = one isolated vault.
- `contracts/mocks/`: unit-test mocks only, not for deployment.
- `public/`: mobile-first static dApp.
- `test/`: Hardhat unit tests.
- `test/fork/`: optional fork test against real Mezo testnet contracts.

## Quick start

```bash
npm install
npx hardhat compile
npx hardhat test
node scripts/export-artifact.js
```

Serve the app:

```bash
python3 -m http.server 8000 --bind 0.0.0.0 --directory public
```

Open `http://localhost:8000` in an EVM wallet browser. For phone-only use, open the hosted URL inside OKX Wallet’s Web3 browser.

## Real contract verification

```bash
npx hardhat run scripts/check-real-contracts.js
```

This checks canonical MUSD and sMUSD on Mezo testnet and verifies `savings.musdToken() == MUSD`.

## Fork test

```bash
FORK_MEZO_TESTNET=1 npx hardhat test test/fork/BillVault.fork.test.js
```

Note: local fork tooling may need custom-chain hardfork configuration. If the fork test fails due to local Hardhat/EDR chain history, use the live testnet flow and record real transaction hashes instead. Do not claim fork-test success unless it passes.

## Deploying from a phone wallet

The app includes a **Deploy bill vault** button. It uses the connected wallet to deploy the compiled `BillVault` bytecode with constructor args:

```text
musd, savings, payee, targetAmount, dueAt, title
```

No private key is entered into the app. The wallet signs the deployment transaction.

## Safety

- Testnet only.
- Fresh test wallet recommended.
- No admin, no upgrades.
- Exact MUSD approval per funding action.
- Reentrancy guard.
- Balance-delta checks after vault withdrawal.
- No native BTC accepted by the contract.
- No guaranteed yield.

## Limitations

- One contract per bill (simple isolation, higher deployment gas).
- Yield is variable and depends on the canonical vault.
- No fiat off-ramp.
- No borrowing in v1.
- No mainnet deployment.
- No audit.

## License

MIT
