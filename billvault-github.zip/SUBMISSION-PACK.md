# BillVault — Mezo Buildathon submission pack

## One-liner

BillVault earmarks MUSD for future bills, earns native Mezo savings yield while waiting, and pays billers directly on-chain.

## Track

Primary: Track 2 — Access & Distribution.  
Secondary alignment: Track 1 — DeFi, because idle MUSD becomes productive capital through Mezo’s native savings vault.

## Chain

Mezo testnet, chain ID 31611.

## Problem

People who hold MUSD for upcoming bills either leave it idle in a wallet or manually move it in and out of savings. That creates friction: forgotten withdrawals, missed payments, and idle bill money.

## Solution

Create a bill vault, fund it with MUSD, and let the contract deposit into Mezo’s canonical MUSD Savings Rate vault. When due, pay the biller directly. Surplus and yield return to the owner.

## Mezo integration

- Uses canonical testnet MUSD.
- Calls canonical testnet sMUSD / MUSD Savings Rate.
- Deposits MUSD into savings.
- Withdraws MUSD to pay bill.
- Reads yield index and claimable yield.
- One isolated contract per bill, no admin custody.

## Target user

Crypto-native freelancers, small merchants, DAO operators, and households that receive MUSD and need to pay future bills.

## Business model

Current prototype: no fee, no revenue.  
Future options:

- premium reminders/automation;
- business treasury dashboard;
- embeddable bill-payment widget;
- small fee on realized yield, only if transparent and user-approved.

## Evidence to include

- Live app URL.
- Public GitHub repo.
- Deployed BillVault contract address(es).
- Deploy transaction hash.
- Fund transaction hash.
- Pay transaction hash.
- Optional cancel transaction hash.
- Explorer links.
- Test output: 16 unit tests passing.
- Real contract verification output.
- Outside tester transaction if available.

## Honest limitations

- Testnet only.
- No mainnet.
- No fiat payout.
- No borrowing in v1.
- No audit.
- Yield variable, not guaranteed.
- No real revenue yet.
- One contract per bill increases deployment gas.

## Future milestones

1. Outside pilot with 3–5 testnet users and feedback.
2. Security review, improved yield accounting, optional reminders.
3. Mainnet readiness review and small capped launch if safe.

## 2-minute video script

**0:00–0:15**  
“People hold MUSD for future bills, but idle balances do not earn native savings yield. Withdrawing manually before every payment is easy to forget.”

**0:15–0:35**  
“BillVault lets you create a bill, fund it with MUSD, and automatically route funds into Mezo’s native savings vault until the bill is paid.”

**0:35–1:20**  
Screen record:
1. Create bill.
2. Deploy vault.
3. Fund with test MUSD.
4. Pay bill.
5. Show explorer receipt.

**1:20–1:40**  
“This is not a generic stablecoin payment link. It composes directly with Mezo’s MUSD Savings Rate, turning future bill money into productive MUSD.”

**1:40–2:00**  
“Live on Mezo testnet, open source, with real transactions. Next: outside pilots, security review, and optional automation.”

## Deck outline

1. Title: BillVault — yield-bearing bill payments on Mezo.
2. Problem: idle MUSD for future bills.
3. Solution: create → fund → earn → pay.
4. Mezo integration: MUSD + sMUSD vault.
5. Demo/evidence: live app, tx hashes, tests.
6. Business model + limitations.
7. Roadmap + team.

## AKINDO form draft

**Project name:** BillVault  
**Category:** Yield-bearing bill payments  
**TL;DR:** BillVault earmarks MUSD for future bills, earns native Mezo savings yield while waiting, and pays the biller directly on-chain.  
**How it works:** Users create a bill with payee, amount, and due date. Deposited MUSD is routed into Mezo’s native MUSD Savings Rate vault. When due, the contract withdraws MUSD and pays the payee. Owner keeps yield and can cancel before payment.  
**Target group:** Crypto-native freelancers, small merchants, DAO operators, and households holding MUSD for future bills.  
**Track:** Track 2, secondary Track 1 alignment.  
**Chain:** Mezo testnet.  
**Status:** New project built during hackathon.  
**Readiness:** Testnet deployment.  
**Future milestones:** outside pilot, security review, mainnet readiness.
